import React, { useEffect, useMemo, useRef, useState } from 'react';
import Fuse from 'fuse.js';
import { useHotkeys } from 'react-hotkeys-hook';
import '../../styles/TagWorkbench.css';
import allCardsJson from '/src/assets/allCards.json';
import donCardsJson from '/src/assets/donCards.json';
import { inferTagsFromText } from '../../utils/tagParser.js';
import { saveManualTags } from '../../services/tagsStore.js';

// Types (JS version)
// Card: { id, name, text, color, cardSetCode, cardType, imageUrl, cost, power, traits }

const IMAGE_PATH = `${import.meta.env.BASE_URL}cards`;

const defaultTagsFile = { meta: { version: 1, vocabVersion: 1 }, cards: {} };

export default function TagWorkbench({ onClose }) {
  const [cards, setCards] = useState({});
  const [regularIds, setRegularIds] = useState([]);
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [tags, setTags] = useState(defaultTagsFile);
  const [vocab, setVocab] = useState({ produces: {}, requires: {}, mechanics: [] });
  const [filter, setFilter] = useState({ color: '', set: '', type: '' });
  const [currentSection, setCurrentSection] = useState('produces');
  const [showLeft, setShowLeft] = useState(true);
  const [showRight, setShowRight] = useState(true);
  const [leaderId, setLeaderId] = useState('');
  const [leaders, setLeaders] = useState([]);
  const [observed, setObserved] = useState({ produces: new Set(), requires: new Set(), mechanics: new Set() });
  const [observedTop, setObservedTop] = useState({ produces: [], requires: [], mechanics: [] });

  useEffect(() => {
    const merged = { ...allCardsJson, ...donCardsJson };
    setCards(merged);
    const ids = Object.keys(merged).filter(id => id.indexOf('_') === -1);
    setRegularIds(ids);
    const leadersList = ids.filter(id => (merged[id]?.cardType || '') === 'Leader');
    setLeaders(leadersList);
    // load persisted tags/vocab from public data (or defaults)
    Promise.all([
      fetch(`${import.meta.env.BASE_URL}data/synergy_tags.json`).then(r => r.ok ? r.json() : defaultTagsFile).catch(() => defaultTagsFile),
      fetch(`${import.meta.env.BASE_URL}data/vocab.json`).then(r => r.ok ? r.json() : { produces: {}, requires: {}, mechanics: [] }).catch(() => ({ produces: {}, requires: {}, mechanics: [] })),
    ]).then(([t, v]) => {
      const local = localStorage.getItem('synergy_tags');
      setTags(local ? JSON.parse(local) : t);
      setVocab(v);
    });
  }, []);

  useEffect(() => {
    const prod = new Set();
    const req = new Set();
    const mech = new Set();
    const prodCount = new Map();
    const reqCount = new Map();
    const mechCount = new Map();
    for (const entry of Object.values(tags.cards || {})) {
      // count manual tokens (aligns with synergy_index intent)
      for (const t of (entry.manual?.produces || [])) { prod.add(t); prodCount.set(t, (prodCount.get(t) || 0) + 1); }
      for (const t of (entry.manual?.requires || [])) { req.add(t); reqCount.set(t, (reqCount.get(t) || 0) + 1); }
      for (const t of (entry.manual?.mechanics || [])) { mech.add(t); mechCount.set(t, (mechCount.get(t) || 0) + 1); }
      // include auto in observed sets for autocomplete breadth (not counts)
      (entry.auto?.produces || []).forEach(t => prod.add(t));
      (entry.auto?.requires || []).forEach(t => req.add(t));
      (entry.auto?.mechanics || []).forEach(t => mech.add(t));
    }
    const sortTop = (m) => Array.from(m.entries()).sort((a,b)=>b[1]-a[1]).slice(0,12).map(([t,c])=>({ t, c }));
    setObserved({ produces: prod, requires: req, mechanics: mech });
    setObservedTop({ produces: sortTop(prodCount), requires: sortTop(reqCount), mechanics: sortTop(mechCount) });
  }, [tags]);

  const fuse = useMemo(() => new Fuse(regularIds.map(id => ({ id, name: cards[id]?.name ?? '' })), { keys: ['name', 'id'], threshold: 0.3 }), [regularIds, cards]);

  const filteredIds = useMemo(() => {
    let ids = regularIds;
    if (filter.color) ids = ids.filter(id => (cards[id]?.color || []).includes(filter.color));
    if (filter.set) ids = ids.filter(id => (cards[id]?.cardSetCode || '').startsWith(filter.set));
    if (filter.type) ids = ids.filter(id => (cards[id]?.cardType || '') === filter.type);
    if (leaderId) {
      const leaderTraits = (cards[leaderId]?.traits || []).map(t => String(t));
      const leaderType = String(cards[leaderId]?.cardType || '');
      const leaderReqs = new Set([
        ...leaderTraits.map(t => `LeaderIsTrait:${t}`),
        ...leaderTraits.map(t => `LeaderTypeIncludes:${t}`),
        `LeaderTypeIncludes:${leaderType}`,
      ]);
      ids = ids.filter(id => {
        const entry = tags.cards[id] || {};
        const reqs = new Set([...(entry.manual?.requires || []), ...(entry.auto?.requires || [])]);
        const hasLeaderReq = Array.from(reqs).some(r => r.startsWith('LeaderIsTrait:') || r.startsWith('LeaderTypeIncludes:'));
        const matchesLeader = Array.from(reqs).some(r => leaderReqs.has(r));
        return !hasLeaderReq || matchesLeader;
      });
    }
    if (!query) return ids;
    return fuse.search(query).map(r => r.item.id).filter(id => ids.includes(id));
  }, [regularIds, cards, filter, query, fuse, leaderId, tags]);

  const selectedId = filteredIds[selectedIndex];
  const card = cards[selectedId] || {};
  const manual = tags.cards[selectedId]?.manual || { produces: [], requires: [], mechanics: [] };
  const auto = tags.cards[selectedId]?.auto || { produces: [], requires: [], mechanics: [] };

  // auto-tag inference for current card if missing
  useEffect(() => {
    if (!selectedId) return;
    const entry = tags.cards[selectedId];
    if (!entry || !entry.auto || ((entry.auto.produces||[]).length + (entry.auto.requires||[]).length + (entry.auto.mechanics||[]).length) === 0) {
      const inferred = inferTagsFromText(card?.text);
      setTags(prev => ({
        ...prev,
        cards: {
          ...prev.cards,
          [selectedId]: { ...(prev.cards[selectedId] || {}), auto: inferred, manual: prev.cards[selectedId]?.manual }
        }
      }));
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId]);

  // debounced save of manual tags when manual changes
  const saveTimer = useRef(0);
  useEffect(() => {
    if (!selectedId) return;
    window.clearTimeout(saveTimer.current);
    saveTimer.current = window.setTimeout(() => {
      const m = tags.cards[selectedId]?.manual;
      if (!m) return;
      saveManualTags(selectedId, m, { reviewed: tags.cards[selectedId]?.reviewed, notes: tags.cards[selectedId]?.notes });
    }, 500);
    return () => window.clearTimeout(saveTimer.current);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId, manual.produces?.join(','), manual.requires?.join(','), manual.mechanics?.join(','), tags.cards[selectedId]?.reviewed]);

  const isNeedsReview = (id) => {
    const entry = tags.cards[id];
    const m = entry?.manual;
    const manualEmpty = !m || ((m.produces?.length || 0) + (m.requires?.length || 0) + (m.mechanics?.length || 0)) === 0;
    return manualEmpty || entry?.reviewed === false || entry?.reviewed == null;
  };

  // Hotkeys
  useHotkeys('j', () => setSelectedIndex(i => Math.min(i + 1, filteredIds.length - 1)), [filteredIds.length]);
  useHotkeys('k', () => setSelectedIndex(i => Math.max(i - 1, 0)), [filteredIds.length]);
  useHotkeys('f', (e) => { e.preventDefault(); document.getElementById('tag-search-input')?.focus(); }, []);
  useHotkeys('1', (e) => { e.preventDefault(); setCurrentSection('produces'); document.getElementById('twb-input-produces')?.focus(); }, []);
  useHotkeys('2', (e) => { e.preventDefault(); setCurrentSection('requires'); document.getElementById('twb-input-requires')?.focus(); }, []);
  useHotkeys('3', (e) => { e.preventDefault(); setCurrentSection('mechanics'); document.getElementById('twb-input-mechanics')?.focus(); }, []);
  useHotkeys('a', (e) => { e.preventDefault(); copyAutoToManual(currentSection); }, [currentSection, manual, auto]);
  useHotkeys('r', (e) => { e.preventDefault(); toggleReviewed(); }, [selectedId, tags]);
  useHotkeys('s', (e) => { e.preventDefault(); localStorage.setItem('synergy_tags', JSON.stringify(tags)); }, [tags]);
  useHotkeys('n', (e) => {
    e.preventDefault();
    for (let i = selectedIndex + 1; i < filteredIds.length; i++) {
      if (isNeedsReview(filteredIds[i])) { setSelectedIndex(i); return; }
    }
  }, [filteredIds, selectedIndex, tags]);
  useHotkeys('p', (e) => {
    e.preventDefault();
    for (let i = selectedIndex - 1; i >= 0; i--) {
      if (isNeedsReview(filteredIds[i])) { setSelectedIndex(i); return; }
    }
  }, [filteredIds, selectedIndex, tags]);

  const updateManual = (section, tokens) => {
    setTags(prev => ({
      ...prev,
      cards: {
        ...prev.cards,
        [selectedId]: {
          ...(prev.cards[selectedId] || {}),
          manual: {
            ...(prev.cards[selectedId]?.manual || { produces: [], requires: [], mechanics: [] }),
            [section]: tokens,
          },
        },
      },
    }));
  };

  const copyAutoToManual = (section) => {
    const cur = new Set(manual[section] || []);
    (auto[section] || []).forEach(t => cur.add(t));
    updateManual(section, Array.from(cur));
  };

  const toggleReviewed = () => {
    if (!selectedId) return;
    setTags(prev => ({
      ...prev,
      cards: {
        ...prev.cards,
        [selectedId]: {
          ...(prev.cards[selectedId] || {}),
          manual: prev.cards[selectedId]?.manual || { produces: [], requires: [], mechanics: [] },
          reviewed: !(prev.cards[selectedId]?.reviewed === true),
        },
      },
    }));
  };

  const downloadJson = (name, obj) => {
    const blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const rebuildIndex = () => {
    const byProduces = {};
    const byRequires = {};
    for (const [id, entry] of Object.entries(tags.cards || {})) {
      const m = entry?.manual || { produces: [], requires: [], mechanics: [] };
      (m.produces || []).forEach(t => {
        if (!byProduces[t]) byProduces[t] = [];
        byProduces[t].push(id);
      });
      (m.requires || []).forEach(t => {
        if (!byRequires[t]) byRequires[t] = [];
        byRequires[t].push(id);
      });
    }
    const index = { byProduces, byRequires };
    downloadJson('synergy_index.json', index);
  };

  const loadFromFile = (evt) => {
    const file = evt.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        if (parsed?.meta && parsed?.cards) {
          setTags(parsed);
          localStorage.setItem('synergy_tags', JSON.stringify(parsed));
        }
      } catch {}
    };
    reader.readAsText(file);
  };

  const leftWidth = showLeft ? '300px' : '0px';
  const rightWidth = showRight ? '360px' : '0px';
  return (
    <div className='twb-root'>
      <div className='twb-header'>
        <div className='twb-header-row'>
          <div className='twb-header-left'>
            <button className='twb-toggle' onClick={() => setShowLeft(v => !v)}>{showLeft ? 'Hide List' : 'Show List'}</button>
            <button className='twb-toggle' onClick={() => setShowRight(v => !v)}>{showRight ? 'Hide Editor' : 'Show Editor'}</button>
            <span className='twb-badge'>Regular art only: {regularIds.length.toLocaleString()}</span>
            <select className='twb-btn' value={leaderId} onChange={e => setLeaderId(e.target.value)}>
              <option value=''>Leader: Any</option>
              {leaders.map(id => <option key={id} value={id}>{cards[id]?.name}</option>)}
            </select>
          </div>
          <div className='twb-header-right'>
            <input id='tag-search-input' className='twb-search' value={query} onChange={e => setQuery(e.target.value)} placeholder='Search name or id (f)' />
            <button className='twb-btn' onClick={() => { localStorage.setItem('synergy_tags', JSON.stringify(tags)); }}>Save (s)</button>
            <button className='twb-btn' onClick={() => downloadJson('synergy_tags.json', tags)}>Export</button>
            <label className='twb-btn'>
              <input type='file' accept='application/json' style={{ display: 'none' }} onChange={loadFromFile} />
              Import
            </label>
            <button className='twb-btn' onClick={rebuildIndex}>Rebuild Index</button>
          </div>
        </div>
      </div>
      <div className='twb-body' style={{ gridTemplateColumns: `${leftWidth} 1fr ${rightWidth}` }}>
        <div className='twb-left'>
          <div className='twb-list'>
            {filteredIds.map((id, idx) => (
              <div key={id} className={idx === selectedIndex ? 'twb-row twb-row-active' : 'twb-row'} onClick={() => setSelectedIndex(idx)}>
                <img src={`${IMAGE_PATH}/${cards[id]?.cardSetCode}/${id}.png`} />
                <div>
                  <div className='twb-name'>{cards[id]?.name}</div>
                  <div className='twb-sub'>{cards[id]?.cardSetCode} • {cards[id]?.cardType}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className='twb-center'>
          <div className='twb-card-header'>
            <div className='twb-title'>{card?.name}</div>
            <div className='twb-meta'>{selectedId} • {card?.cardSetCode} • {card?.cardType}</div>
          </div>
          <div className='twb-rules'>
            {card?.text ? card.text : 'No rules text available.'}
          </div>
          <div className='twb-auto'>
            <div className='twb-section'>
              <div className='twb-section-title'>Auto Produces</div>
              <div className='twb-chips'>{(auto.produces || []).map(t => <span className='twb-chip' key={t}>{t}</span>)}</div>
              <button onClick={() => copyAutoToManual('produces')}>Copy AUTO → MANUAL (a)</button>
            </div>
            <div className='twb-section'>
              <div className='twb-section-title'>Auto Requires</div>
              <div className='twb-chips'>{(auto.requires || []).map(t => <span className='twb-chip' key={t}>{t}</span>)}</div>
              <button onClick={() => copyAutoToManual('requires')}>Copy AUTO → MANUAL (a)</button>
            </div>
            <div className='twb-section'>
              <div className='twb-section-title'>Auto Mechanics</div>
              <div className='twb-chips'>{(auto.mechanics || []).map(t => <span className='twb-chip' key={t}>{t}</span>)}</div>
              <button onClick={() => copyAutoToManual('mechanics')}>Copy AUTO → MANUAL (a)</button>
            </div>
          </div>
        </div>
        <div className='twb-right'>
          <EditorSection title='Produces' bucket='produces' inputId='twb-input-produces' onFocusSection={() => setCurrentSection('produces')} value={manual.produces || []} onChange={v => updateManual('produces', v)} observed={observed.produces} observedTop={observedTop.produces} vocab={vocab} />
          <EditorSection title='Requires' bucket='requires' inputId='twb-input-requires' onFocusSection={() => setCurrentSection('requires')} value={manual.requires || []} onChange={v => updateManual('requires', v)} observed={observed.requires} observedTop={observedTop.requires} vocab={vocab} />
          <EditorSection title='Mechanics' bucket='mechanics' inputId='twb-input-mechanics' onFocusSection={() => setCurrentSection('mechanics')} value={manual.mechanics || []} onChange={v => updateManual('mechanics', v)} observed={observed.mechanics} observedTop={observedTop.mechanics} vocab={vocab} />
          <div className='twb-actions'>
            <button onClick={toggleReviewed}>{tags.cards[selectedId]?.reviewed ? 'Unreview' : 'Mark Reviewed'} (r)</button>
            <button onClick={() => onClose?.()}>Close</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function EditorSection({ title, value, onChange, inputId, onFocusSection, bucket, observed, observedTop, vocab }) {
  const [input, setInput] = useState('');
  const [showList, setShowList] = useState(false);
  const listRef = useRef(null);
  const [num, setNum] = useState('');
  const [numA, setNumA] = useState('');
  const [numB, setNumB] = useState('');
  const [trait, setTrait] = useState('');

  const observedList = useMemo(() => Array.from(observed || new Set()).sort(), [observed]);
  const vocabList = useMemo(() => {
    if (bucket === 'mechanics') return (vocab.mechanics || []).slice();
    const rec = bucket === 'produces' ? vocab.produces || {} : vocab.requires || {};
    return Object.keys(rec || {});
  }, [bucket, vocab]);

  const validate = (token) => {
    if (bucket === 'mechanics') return (vocab.mechanics || []).includes(token);
    const rec = bucket === 'produces' ? vocab.produces || {} : vocab.requires || {};
    if (rec[token]) return true;
    const patterns = Object.values(rec);
    for (const pat of patterns) {
      try { if (new RegExp(pat).test(token)) return true; } catch {}
    }
    return false;
  };

  const add = () => {
    const parts = input.split(/[\s,\n]+/).map(x => x.trim()).filter(Boolean);
    if (parts.length === 0) return;
    const cur = new Set(value);
    parts.forEach(p => cur.add(p));
    onChange(Array.from(cur));
    setInput('');
    setShowList(false);
  };
  const onKeyDown = (e) => {
    if (e.key === 'Enter') { e.preventDefault(); add(); }
    else if (e.key === ',') { e.preventDefault(); add(); }
    else if (e.key === 'Backspace' && input.length === 0 && value.length > 0) {
      onChange(value.slice(0, -1));
    }
  };

  const filteredObserved = useMemo(() => observedList.filter(t => t.toLowerCase().includes(input.toLowerCase())), [observedList, input]);
  const filteredVocab = useMemo(() => vocabList.filter(t => t.toLowerCase().includes(input.toLowerCase())), [vocabList, input]);

  const pushToken = (tok) => onChange(Array.from(new Set([...value, tok].filter(Boolean))));

  return (
    <div className='twb-section'>
      <div className='twb-section-title'>{title}</div>
      {observedTop && observedTop.length > 0 && (
        <div className='twb-templates-row'>
          {observedTop.map(({ t, c }) => (
            <button key={t} className='twb-btn' title={`${c} cards`} onClick={() => pushToken(t)}>{t}</button>
          ))}
        </div>
      )}
      <div className='twb-chips'>
        {value.map(t => (
          <span className='twb-chip' key={t} title={validate(t) ? 'Valid' : 'Invalid'} style={{ outline: validate(t) ? 'none' : '1px solid #f66' }}>
            <span className='twb-chip-label'>{t}</span>
            <button className='twb-chip-remove' onClick={() => onChange(value.filter(x => x !== t))}>×</button>
          </span>
        ))}
      </div>
      <input id={inputId} value={input} onFocus={(e) => { onFocusSection?.(); setShowList(true); }} onBlur={() => setTimeout(()=>setShowList(false), 200)} onChange={e => setInput(e.target.value)} onKeyDown={onKeyDown} placeholder={`Add ${title}…`} />
      <button onClick={add}>Add</button>
      <div className='twb-templates'>
        {bucket === 'produces' && (
          <>
            <div className='twb-templates-row'>
              <input className='twb-input-small' placeholder='n' value={num} onChange={e => setNum(e.target.value.replace(/[^0-9]/g,''))} />
              <button className='twb-btn' onClick={() => pushToken('ReducePower:' + num + ':ThisTurn:Scope:EnemyAny')}>ReducePower n</button>
              <button className='twb-btn' onClick={() => pushToken('ReduceCost:' + num + ':ThisTurn')}>ReduceCost n</button>
              <button className='twb-btn' onClick={() => pushToken('SetCost:' + num + ':ThisTurn')}>SetCost n</button>
              <button className='twb-btn' onClick={() => pushToken('KO:Cost<=' + num)}>KO Cost ≤ n</button>
              <button className='twb-btn' onClick={() => pushToken('Rest:BaseCost<=' + num)}>Rest BaseCost ≤ n</button>
            </div>
            <div className='twb-templates-row'>
              <button className='twb-btn' onClick={() => pushToken('AttachRestedDON:' + num + ':Targets:Leader|Character')}>AttachRestedDON n</button>
              <button className='twb-btn' onClick={() => pushToken('LookTop:' + num)}>LookTop n</button>
              <button className='twb-btn' onClick={() => pushToken('ArrangeTop:' + num)}>ArrangeTop n</button>
              <button className='twb-btn' onClick={() => pushToken('ArrangeBottom:' + num)}>ArrangeBottom n</button>
              <button className='twb-btn' onClick={() => pushToken('PlaceRest:Top')}>PlaceRest Top</button>
              <button className='twb-btn' onClick={() => pushToken('PlaceRest:Bottom')}>PlaceRest Bottom</button>
              <button className='twb-btn' onClick={() => pushToken('PlayFromTop:Cost<=' + num)}>PlayFromTop ≤ n</button>
            </div>
            <div className='twb-templates-row'>
              <input className='twb-input-small' placeholder='a' value={numA} onChange={e => setNumA(e.target.value.replace(/[^0-9]/g,''))} />
              <input className='twb-input-small' placeholder='b' value={numB} onChange={e => setNumB(e.target.value.replace(/[^0-9]/g,''))} />
              <button className='twb-btn' onClick={() => pushToken('PlayFromTrash:CostRange:' + numA + '-' + numB)}>PlayFromTrash a-b</button>
              <button className='twb-btn' onClick={() => pushToken('PlayFromTrash:Cost<=' + num)}>PlayFromTrash ≤ n</button>
            </div>
          </>
        )}
        {bucket === 'requires' && (
          <>
            <div className='twb-templates-row'>
              <button className='twb-btn' onClick={() => pushToken('Enable:LowerPower')}>Enable LowerPower</button>
              <button className='twb-btn' onClick={() => pushToken('Enable:LowerCost')}>Enable LowerCost</button>
              <button className='twb-btn' onClick={() => pushToken('OnlyOppTurn')}>OnlyOppTurn</button>
              <button className='twb-btn' onClick={() => pushToken('OncePerTurn')}>OncePerTurn</button>
            </div>
            <div className='twb-templates-row'>
              <input className='twb-input-small' placeholder='Trait' value={trait} onChange={e => setTrait(e.target.value)} />
              <button className='twb-btn' onClick={() => pushToken('LeaderIsTrait:' + trait)}>LeaderIsTrait</button>
              <input className='twb-input-small' placeholder='n' value={num} onChange={e => setNum(e.target.value.replace(/[^0-9]/g,''))} />
              <button className='twb-btn' onClick={() => pushToken('NeedsDONAttachedToSelf>=' + num)}>NeedsDONAttachedToSelf≥n</button>
              <button className='twb-btn' onClick={() => pushToken('CostDiscardFromHand>=' + num)}>DiscardFromHand≥n</button>
              <button className='twb-btn' onClick={() => pushToken('NeedsTrashTrait:' + trait + '>=' + num)}>NeedsTrashTrait trait≥n</button>
            </div>
          </>
        )}
        {bucket === 'mechanics' && (
          <div className='twb-templates-row'>
            {(vocab.mechanics || []).slice(0, 8).map(m => (
              <button key={m} className='twb-btn' onClick={() => pushToken(m)}>{m}</button>
            ))}
          </div>
        )}
      </div>
      {showList && (input.length > 0) && (
        <div className='twb-suggest' ref={listRef}>
          {filteredObserved.length > 0 && <div className='twb-suggest-group'>
            <div className='twb-suggest-title'>Observed</div>
            {filteredObserved.slice(0, 8).map(s => <div key={s} className='twb-suggest-item' onMouseDown={() => { setInput(s); setTimeout(add, 0); }}>{s}</div>)}
          </div>}
          {filteredVocab.length > 0 && <div className='twb-suggest-group'>
            <div className='twb-suggest-title'>Vocab</div>
            {filteredVocab.slice(0, 8).map(s => <div key={s} className='twb-suggest-item' onMouseDown={() => { setInput(s); setTimeout(add, 0); }}>{s}</div>)}
          </div>}
        </div>
      )}
    </div>
  );
}
