export const StorageType = {
    COLLECTION: 'COLLECTION',
    FOR_TRADE: 'FOR_TRADE',
    LOOKING_FOR: 'LOOKING_FOR',
    EXTRA_TYPES: 'EXTRA_TYPES',
};