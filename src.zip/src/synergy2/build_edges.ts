// Build edges_v2 from tags_v2
import * as fs from "fs";
import * as path from "path";

type Effects = { inbound?: string[]; outbound?: string[]; keywords?: string[] };
type TagsFileV2 = { meta: any; cards: Record<string, { manual?: Effects; auto?: Effects }> };
type EdgeV2 = { from: string; to: string; reason: string; score: number };

const inPath = path.resolve(process.cwd(), "public/data/synergy_tags_v2.json");
const outPath = path.resolve(process.cwd(), "public/data/synergy_edges_v2.json");
const cardsPath = path.resolve(process.cwd(), "src/assets/allCards.json");

const tags = JSON.parse(fs.readFileSync(inPath, "utf8")) as TagsFileV2;
const CARDS: any = JSON.parse(fs.readFileSync(cardsPath, "utf8"));

function effective(e: { manual?: Effects; auto?: Effects }): Effects {
  const m = e.manual || { inbound: [], outbound: [], keywords: [] };
  if ((m.inbound?.length || 0) + (m.outbound?.length || 0) + (m.keywords?.length || 0) > 0) return m;
  return e.auto || { inbound: [], outbound: [], keywords: [] };
}

const prodIdx: Record<string, string[]> = {};
const reqIdx: Record<string, string[]> = {};

const effBy: Record<string, Effects> = {};
for (const [cid, rec] of Object.entries(tags.cards)) {
  const eff = effective(rec);
  effBy[cid] = eff;
  for (const p of eff.outbound || []) (prodIdx[p] ||= []).push(cid);
  for (const r of eff.inbound || []) (reqIdx[r] ||= []).push(cid);
}

function firstNum(s: string): number | null { const m = s.match(/-?\d{1,6}/); return m ? parseInt(m[0], 10) : null; }

let edges: EdgeV2[] = [];

// NOTE: DON ladder removed per request (too dense).

// Cost windows vs reducers
(function costWindows(){
  const reducers = Object.keys(prodIdx).filter(k => /^CostMod:[-+]\d+$/.test(k));
  const kos = Object.keys(prodIdx).filter(k => /^KO:Cost<=\d+$/.test(k));
  const rests = Object.keys(prodIdx).filter(k => /^RestTarget:Cost<=\d+$/.test(k));
  for (const red of reducers) {
    const rVal = Math.abs(firstNum(red) || 0);
    for (const w of [...kos, ...rests]) {
      const wVal = firstNum(w) || 0;
      const ratio = wVal ? Math.min(1, rVal / wVal) : 0.5;
      for (const from of prodIdx[red]) for (const to of prodIdx[w]) if (from !== to) edges.push({ from, to, reason: w.startsWith("KO")?"Cost ladder (window)":"Cost ladder (window)", score: ratio });
    }
  }
})();

// Power windows
(function powerWindows(){
  const reducers: string[] = []; // placeholder if you add ReducePower in v2
  const kos = Object.keys(prodIdx).filter(k => /^KO:Power<=\d+$/.test(k));
  for (const red of reducers) {
    const rVal = Math.abs(firstNum(red) || 0);
    for (const w of kos) {
      const wVal = firstNum(w) || 0;
      const ratio = wVal ? Math.min(1, rVal / wVal) : 0.5;
      for (const from of prodIdx[red]) for (const to of prodIdx[w]) if (from !== to) edges.push({ from, to, reason: "Power ladder (window)", score: ratio });
    }
  }
})();

// --- Leader/color constraints ---
type Meta = { cardType?: string; color?: string[] };
function getMeta(id: string): Meta {
  const c = CARDS[id];
  return { cardType: c?.cardType, color: Array.isArray(c?.color) ? c.color : [] };
}
function isLeader(id: string) { return (getMeta(id).cardType || "").toUpperCase() === "LEADER"; }
function isPlayableType(id: string) {
  const t = (getMeta(id).cardType || "").toUpperCase();
  return t === "CHARACTER" || t === "EVENT" || t === "STAGE";
}
function colorsSubset(a: string[] = [], b: string[] = []) {
  const setB = new Set((b||[]).map(x=>x?.toLowerCase()));
  return (a||[]).every(x => setB.has((x||"").toLowerCase()));
}
function leaderCompatible(e: EdgeV2): boolean {
  const aL = isLeader(e.from);
  const bL = isLeader(e.to);
  if (aL && bL) return false; // leaders cannot synergize with other leaders
  if (aL && isPlayableType(e.to)) {
    const L = getMeta(e.from).color || [];
    const O = getMeta(e.to).color || [];
    return colorsSubset(O, L);
  }
  if (bL && isPlayableType(e.from)) {
    const L = getMeta(e.to).color || [];
    const O = getMeta(e.from).color || [];
    return colorsSubset(O, L);
  }
  return true;
}

edges = edges.filter(leaderCompatible);

// Dedup keep max score
const best = new Map<string, EdgeV2>();
for (const e of edges) {
  const k = `${e.from}→${e.to}`;
  const prev = best.get(k);
  if (!prev || e.score > prev.score) best.set(k, e);
}

if (!fs.existsSync(path.dirname(outPath))) fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify({ meta: { generatedAt: new Date().toISOString() }, edges: Array.from(best.values()) }, null, 2));
console.log(`Wrote ${outPath} with ${Array.from(best.values()).length} edges`);


